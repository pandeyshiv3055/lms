/* ==========================================================================
   AEGIS DEFENSE & SECURITY — CORE TYPE DEFINITIONS
   ========================================================================== */

export type UserRole = 'learner' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  jobTitle: string;
  department: string;
  badgeCount?: number;
}

export interface AuthSession {
  user: User;
  token: string;
  expiresAt: number;
}

/* ==========================================================================
   Slide Content & Player Schema
   ========================================================================== */

export type SlideType =
  | 'intro'
  | 'instructor'
  | 'title'
  | 'summary'
  | 'text-image'
  | 'image-text'
  | 'bullet-list'
  | 'carousel'
  | 'card-grid'
  | 'scrollable-panel'
  | 'knowledge-check'
  | 'true-false'
  | 'multiple-choice'
  | 'hotspot'
  | 'room-inspection'
  | 'interactive-scenario'
  | 'quiz-intro'
  | 'quiz-question'
  | 'results'
  | 'completion';

export type CompletionRule =
  | 'manual'          // Learner clicks next when available
  | 'timer'           // Must wait for slide timer to elapse
  | 'interaction'     // Must interact with designated element
  | 'explore-all'     // Must open all tabs/cards/carousel items
  | 'pass-check'      // Must answer knowledge check correctly
  | 'all-rooms';      // Must complete room inspection activity

export interface CarouselItem {
  id: string;
  title: string;
  description: string;
  image?: string;
  badgeText?: string;
  keyPoints?: string[];
}

export interface CardGridItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  imageUrl?: string;
  detailedContent: string[];
  actionLabel?: string;
}

export interface ScrollablePanelData {
  panelTitle: string;
  paragraphs: string[];
  keyDirectives?: string[];
  imageOnLeft?: string;
  caption?: string;
  requiresFullScroll?: boolean;
}

export interface KnowledgeCheckOption {
  id: string;
  text: string;
}

export interface KnowledgeCheckData {
  question: string;
  type: 'single-choice' | 'multiple-select' | 'true-false';
  options: KnowledgeCheckOption[];
  correctAnswer: string | string[];
  explanation: string;
  hint?: string;
  maxAttempts?: number;
}

export interface SlideContent {
  headline?: string;
  subtitle?: string;
  bodyParagraphs?: string[];
  bulletPoints?: string[];
  instructorName?: string;
  instructorRole?: string;
  instructorAvatar?: string;
  carouselItems?: CarouselItem[];
  cards?: CardGridItem[];
  scrollablePanel?: ScrollablePanelData;
  knowledgeCheck?: KnowledgeCheckData;
  buildingScenarioId?: string;
  takeawayMessage?: string;
}

export interface Slide {
  id: string;
  lessonId: string;
  title: string;
  type: SlideType;
  narrationText?: string;
  audioUrl?: string;
  durationSeconds?: number;
  requiredDurationSeconds?: number;
  mediaUrl?: string;
  mediaCaption?: string;
  content: SlideContent;
  completionRule: CompletionRule;
}

/* ==========================================================================
   Interactive Room & Building Inspection Simulation
   ========================================================================== */

export interface HotspotCoordinates {
  x: number; // percentage (0 - 100)
  y: number; // percentage (0 - 100)
  width?: number; // percentage
  height?: number; // percentage
  label?: string;
}

export interface InspectionObject {
  id: string;
  label: string;
  hotspot: HotspotCoordinates;
  objectType: 'equipment' | 'furniture' | 'hazard' | 'access' | 'safety' | 'document' | 'other';
  isExpectedTarget: boolean;
  acceptedIncidentCategories?: string[];
  incidentType?: string;
  incidentDetails?: string;
  feedbackCorrect?: string;
  feedbackWhyItMatters?: string;
  severity?: 'low' | 'medium' | 'high' | 'critical';
}

export interface Irregularity {
  id: string;
  name: string;
  description: string;
  category: 'security' | 'safety' | 'maintenance' | 'compliance';
  hotspot: HotspotCoordinates;
  feedbackCorrect: string;
  feedbackWhyItMatters: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface Room {
  id: string;
  name: string;
  code: string;
  buildingCoordinates: HotspotCoordinates;
  roomImage: string;
  required: boolean;
  hasIrregularities: boolean;
  promptQuestion: string; // e.g. "Are there any irregularities in this room?"
  correctAnswerHasIrregularity: boolean;
  explanation: string;
  objects: InspectionObject[];
  correctFeedback?: string;
  incorrectFeedback?: string;
  irregularities: Irregularity[];
}

export interface BuildingScenario {
  id: string;
  title: string;
  description: string;
  buildingImage: string;
  instructions: string;
  rooms: Room[];
  minimumRoomsRequired: number;
}

/* ==========================================================================
   Course & Syllabus Schema
   ========================================================================== */

export type LessonType =
  | 'instructor'
  | 'presentation'
  | 'knowledge-check'
  | 'inspection'
  | 'scenario'
  | 'quiz';

export interface Lesson {
  id: string;
  title: string;
  description: string;
  type: LessonType;
  estimatedMinutes: number;
  slides: Slide[];
  requiresAllSlides: boolean;
}

export interface Module {
  id: string;
  title: string;
  order: number;
  lessons: Lesson[];
}

export type CourseStatus = 'published' | 'draft' | 'archived';

export interface Course {
  id: string;
  code: string;
  title: string;
  category: string;
  description: string;
  shortDescription: string;
  coverImage: string;
  duration: string;
  estimatedMinutes: number;
  level: 'Foundational' | 'Intermediate' | 'Advanced';
  objectives: string[];
  targetAudience: string;
  prerequisites: string[];
  modules: Module[];
  status: CourseStatus;
  badgeRewardId?: string;
  passingScore: number;
  assessmentId?: string;
}

/* ==========================================================================
   Quiz & Assessment Engine
   ========================================================================== */

export interface QuizOption {
  id: string;
  text: string;
}

export interface QuizQuestion {
  id: string;
  text: string;
  type: 'single-choice' | 'multiple-select' | 'true-false' | 'scenario';
  options: QuizOption[];
  correctAnswer: string | string[];
  explanation: string;
  points: number;
  category?: string;
  scenarioContext?: string;
}

export interface Assessment {
  id: string;
  courseId: string;
  title: string;
  instructions: string;
  passingScore: number; // percentage, e.g. 80
  timeLimitMinutes?: number;
  maxAttempts: number;
  randomize: boolean;
  reviewAllowed: boolean;
  questions: QuizQuestion[];
}

export interface QuizAttempt {
  id: string;
  assessmentId: string;
  learnerId: string;
  timestamp: string;
  scorePercentage: number;
  passed: boolean;
  answers: Record<string, string | string[]>;
  feedbackSummary: string;
  earnedPoints: number;
  totalPoints: number;
}

/* ==========================================================================
   Badges, Gamification & Learner Progress
   ========================================================================== */

export interface Badge {
  id: string;
  title: string;
  description: string;
  iconName: string;
  criteria: string;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  category: string;
  color: string;
}

export interface ActivePosition {
  slideIndex: number;
  elapsedSeconds: number;
  interactions: Record<string, any>;
  scrollPosition?: number;
  lastUpdated: string;
}

export interface SubmittedReport {
  roomId: string;
  objectId: string;
  objectLabel: string;
  category: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  isCorrect: boolean;
  submittedAt: string;
  feedbackText: string;
  whyItMatters?: string;
}

export interface RoomInspectionState {
  roomId: string;
  opened: boolean;
  yesNoAnswered: boolean;
  observedIrregularity?: boolean; // user chose Yes (true) or No (false)
  selectedObjectId?: string;
  report?: SubmittedReport;
  isCorrect: boolean;
  status: 'unvisited' | 'in_progress' | 'complete' | 'failed';
  attempts: number;
}

export interface RoomInspectionProgress {
  inspectedRoomIds: string[]; // completed room IDs for backward compat
  reportedIrregularityIds: string[];
  score: number;
  completed: boolean;
  roomAnswers: Record<string, boolean>; // roomId -> answer choice
  roomStates?: Record<string, RoomInspectionState>;
  submittedReports?: Record<string, SubmittedReport>;
}

export interface CourseProgressState {
  courseId: string;
  percentage: number;
  isCompleted: boolean;
  startedAt: string;
  completedAt?: string;
  lastAccessedLessonId?: string;
}

export interface LearnerProgress {
  userId: string;
  courseProgress: Record<string, CourseProgressState>;
  completedLessons: string[];
  completedSlides: Record<string, string[]>; // lessonId -> slideIds
  activeLessonPosition: Record<string, ActivePosition>; // lessonId -> state
  quizAttempts: Record<string, QuizAttempt[]>; // assessmentId -> attempts
  roomInspectionProgress: Record<string, RoomInspectionProgress>; // scenarioId -> progress
  earnedBadges: {
    badgeId: string;
    earnedAt: string;
    courseId?: string;
  }[];
}

/* ==========================================================================
   Media Library & Assets
   ========================================================================== */

export interface MediaAsset {
  id: string;
  name: string;
  type: 'image' | 'audio' | 'illustration' | 'badge';
  url: string;
  thumbnailUrl?: string;
  sizeBytes?: number;
  uploadedAt: string;
  category: string;
  isDemoUploaded?: boolean;
}

/* ==========================================================================
   Application Settings
   ========================================================================== */

export interface AppSettings {
  general: {
    productName: string;
    wordmark: string;
    defaultLanguage: string;
    timeFormat: '12h' | '24h';
    defaultCategory: string;
  };
  player: {
    autoAdvance: boolean;
    defaultNarration: boolean;
    allowReplay: boolean;
    allowRevisitCompleted: boolean;
    requireNarrationFinish: boolean;
    requireCardsExploration: boolean;
    requireAllRoomsInspection: boolean;
  };
  assessment: {
    defaultPassingScore: number;
    defaultMaxAttempts: number;
    immediateFeedback: boolean;
    allowReview: boolean;
  };
  gamification: {
    badgesEnabled: boolean;
    confettiOnPass: boolean;
  };
  learnerAnnouncement?: string;
}
